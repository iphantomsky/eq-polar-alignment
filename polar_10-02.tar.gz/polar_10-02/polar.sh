#!/bin/bash
export PATH="$PATH:/usr/local/astrometry/bin"
WORKDIR=.npa
if [ ! -d ${WORKDIR} ]; then
    mkdir ${WORKDIR}
fi
POLRA=37.9529
POLDEC=89.2642
LAMRA=259.2367
LAMDEC=89.0378
PREFIX=npa_RA
# Polar alignment version #
VER=1
# Script continues at #START

function JNOW {
# formulas from Fundamental Astronomy, by Hannu Karttunen et al, pages 38 onwards
# previous, uncorrected,  behaviour can be simulated by using 2000/01/01 as thisdate
# we assume that the pictures are recent(!) so we take today's date for the NCP.
# currently, date works until 19 January 2038 (!)
#thisdate=2000/01/01
#day=$(date --date $thisdate +%e)
#month=$(date --date $thisdate +%m)
#year=$(date --date $thisdate +%Y)
day=$(date  +%e)
month=$(date  +%m)
year=$(date  +%Y)
# Julian date 
J=$(echo "scale=0; 367*($year)-7*(($year)+(($month)+9)/12)/4-3*((($year)+(($month)-9)/7)/100+1)/4+\
275*($month)/9+($day)+1721029"|bc)
t=$(echo "($J)-2451545"| bc)
T=$(echo "scale=20;(($J)-2451545)/36525"|bc)
# the precession angles
zeta=$(echo  "scale=20;(2306.2181*($T)+0.30188*($T)*($T)+0.017998*($T)*($T)*($T))/3600"|bc)
zed=$(echo   "scale=20;(2306.2181*($T)+1.09468*($T)*($T)+0.018203*($T)*($T)*($T))/3600"|bc)
theta=$(echo "scale=20;(2004.3109*($T)-0.42665*($T)*($T)-0.041833*($T)*($T)*($T))/3600"|bc)
# the precession matrix elements
#p11=$(echo  "scale=20;c(($zed)*a(1)*4/180.0) * c(($theta)*a(1)*4/180.0) * c(($zeta)*a(1)*4/180.0) - \
#s(($zeta)*a(1)*4/180.0) * s(($zed)*a(1)*4/180.0)" |bc -l)
#p12=$(echo  "scale=20;-c(($zed)*a(1)*4/180.0) * c(($theta)*a(1)*4/180.0) * s(($zeta)*a(1)*4/180.0) - \
#s(($zed)*a(1)*4/180.0) * c(($zeta)*a(1)*4/180.0)" |bc -l)
#p13=$(echo  "scale=20;-c(($zed)*a(1)*4/180.0) * s(($theta)*a(1)*4/180.0) " |bc -l)
#p21=$(echo  "scale=20;s(($zed)*a(1)*4/180.0) * c(($theta)*a(1)*4/180.0) * c(($zeta)*a(1)*4/180.0) + \
#c(($zed)*a(1)*4/180.0) * s(($zeta)*a(1)*4/180.0)" |bc -l)
#p22=$(echo  "scale=20;-s(($zed)*a(1)*4/180.0) * c(($theta)*a(1)*4/180.0) * s(($zeta)*a(1)*4/180.0) + \
#c(($zed)*a(1)*4/180.0) * c(($zeta)*a(1)*4/180.0)" |bc -l)
#p23=$(echo  "scale=20;-s(($zed)*a(1)*4/180.0) * s(($theta)*a(1)*4/180.0)" |bc -l)
#p31=$(echo  "scale=20;s(($theta)*a(1)*4/180.0) * c(($zeta)*a(1)*4/180.0) " |bc -l)
#p32=$(echo  "scale=20;-s(($theta)*a(1)*4/180.0) * s(($zeta)*a(1)*4/180.0) " |bc -l)
#p33=$(echo  "scale=20;c(($theta)*a(1)*4/180.0)" |bc -l)

# NCP is at 3-coordinate column vector (0 0 1)
# we need to apply the inverse of the precession matrix so, if (a,d) is what we're after
# 
# cos d * cos a =  p31 =  sin theta * cos zeta
# cos d * sin a =  p32 = -sin theta * sin zeta
# sin d         =  p33 =  cos theta
#
# take f as the complement of d (=pi/2-d) as d is very close to 90 degrees
# sin f * cos a =  p31 =  sin theta * cos zeta
# sin f * sin a =  p32 = -sin theta * sin zeta
# cos f         =  p33 =  cos theta
# 
# so f = theta, a = - zeta
ncpdec=$(echo "scale=20; 90-($theta)"| bc -l)
ncpdecsexa=$(echo "scale=1; $ncpdec * 3600" |bc -l |.npa/.hexa.bc|colrm 11)
ncpradeg=$(echo "scale=20; -($zeta)"|bc -l)
ncprahour=$(echo "scale=20; 24.-($zeta)*24.0/360.0"|bc -l)
ncprahoursexa=$(echo "scale=1; $ncprahour * 3600" |bc -l |.npa/.hexa.bc|colrm 11)
}

function checkupdate {
        if [ `ping -c1 www.thefroginator.co.uk >/dev/null 2>&1 ; echo $?` != 0 ] ; then
                echo "Update server offline, proceeding with current version."
        else
                runupdate
        fi
}
function runupdate {
        NV=`links -dump http://www.thefroginator.co.uk/polar/version | awk '{print $1}'`
        if [ "${NV}" = "${VER}" ] ; then
                echo "Currently running most up-to-date version, ${VER}."
                echo ""
        elif [ "${NV}" -gt "${VER}" ] ; then
                echo "Currently running version ${VER}, however version ${NV} is available."
                echo "Beginning update."
                wget -q -O ./polar-${NV}.sh http://www.theforginator.co.uk/polar/polar.sh
                if [ "$?" != "0" ] ; then
                        echo "Update failed, continuing with current version."
                else
                        chmod +x ./polar-${NV}.sh
                        echo ""
                        echo "Version ${NV} downloaded - restarting."
                        echo "--------------------------------------"
                        ln -sf ./polar-${NV}.sh ./polar.sh
                        ./polar-${NV}.sh
                        exit $?
                fi
        elif [ "${NV}" -lt "${VER}" ] ; then
                echo "**** You're running a newer version than available, I'm probably classed \
as unstable, so beware! ****"
        fi
}

function dot_files () {
if [ ! -d ${HOME}/.polar ] ; then 
    mkdir ${HOME}/.polar
fi
cat > ${HOME}/.polar/.cameras.init <<EOF
# Add options for each imaging setup you use
# First line: TRUE or FALSE
# determines which one will be already selected in the radiobox
#
# Second line: free text
# give enough information so that you'll remember if that's the one you want!
#
# Third line: solve-field options
# self evident 
# 
# PS: don't leave blank lines unless you mean it
TRUE
Default

FALSE
Panasonic DMC-GF1
--downsample 2 --scale-low 10 --scale-high 30 --scale-units app --no-tweak
FALSE
Canon Powershot 710IS full zoom
--downsample 2 --scale-low 15 --scale-high 20 --scale-units app --no-tweak
FALSE
Canon 450D 135mm 
--downsample 2 --scale-low 6 --scale-high 10 --scale-units app --no-tweak
EOF
if [ ! -f ${HOME}/.polar/.cameras ] ; then 
    cp ${HOME}/.polar/.cameras.init ${HOME}/.polar/.cameras
fi
if [ ! -f ${HOME}/.polar/.exptime ] ; then 
    echo 60 >  ${HOME}/.polar/.exptime
fi
if [ ! -f ${HOME}/.polar/.declination ] ; then 
    echo 40 >  ${HOME}/.polar/.declination
fi
if [ ! -f ${HOME}/.polar/.solveopts ] ; then 
    echo  >  ${HOME}/.polar/.solveopts
fi
}

function ready_progs () {
cat > ${WORKDIR}/.hexa.bc <<EOF
#!/usr/bin/bc -l
x=read()
sign=1
if (x<0) {x=-x; sign=-1}
scale=0
m=x/60
secs=x-m*60
deg=m/60
min=m-deg*60
print "",sign*deg,":",min,":",secs, "\n"
quit
EOF
chmod 700 ${WORKDIR}/.hexa.bc 
cat > ${WORKDIR}/.plot.bc <<EOF
#!/usr/bin/bc -l
scale=0
px=read()
lx=read()
ncpx=read()
rax=read()
py=read()
ly=read()
ncpy=read()
ray=read()
imgsca=read()
ncpx2000=read()
ncpy2000=read()
# compute minimum x
if (px<lx) minx=px else minx=lx
if (minx>ncpx) minx=ncpx
if (minx>rax) minx=rax
# compute maximum x
if (px>lx) maxx=px else maxx=lx
if (maxx<ncpx) maxx=ncpx
if (maxx<rax) maxx=rax
# compute minimum y
if (py<ly) miny=py else miny=ly
if (miny>ncpy) miny=ncpy
if (miny>ray) miny=ray
# compute maximum y
if (py>ly) maxy=py else maxy=ly
if (maxy<ncpy) maxy=ncpy
if (maxy<ray) maxy=ray
# 
fivemin=300/imgsca
fivepix=5
border=200
if(minx<border) border=minx
if(miny<border) border=miny
#
print "convert -fill none -stroke cyan "
#draw circles around NCP at 5, 10 and 20 arcminutes radius
print "-draw 'circle ",ncpx,",",ncpy," ",ncpx+fivemin,",",ncpy,"' "
print "-draw 'circle ",ncpx,",",ncpy," ",ncpx+2*fivemin,",",ncpy,"' "
print "-draw 'circle ",ncpx,",",ncpy," ",ncpx+4*fivemin,",",ncpy,"' "
print "-draw 'circle ",ncpx,",",ncpy," ",ncpx+8*fivemin,",",ncpy,"' "
print "-draw \qtext ",ncpx+fivemin  ," ",ncpy," '5'\q "
print "-draw \qtext ",ncpx+2*fivemin," ",ncpy," '10'\q "
print "-draw \qtext ",ncpx+4*fivemin," ",ncpy," '20\\\\'\q "
print "-draw \qtext ",ncpx+8*fivemin," ",ncpy," '40\\\\'\q "
#draw circles around NCP 2000 at 5
print "-stroke green "
print "-draw 'circle ",ncpx2000,",",ncpy2000," ",ncpx2000+fivemin,",",ncpy2000,"' "
# draw x on RA axis
print "-stroke red "
print "-draw 'line "  ,rax-fivemin,",", ray-fivemin," ", rax+fivemin,",", ray+fivemin,"' "
print "-draw 'line "  ,rax-fivemin,",", ray+fivemin," ", rax+fivemin,",", ray-fivemin,"' "
#draw + around stars
print "-stroke white "
print "-draw 'line "  ,px         ,",", py+fivepix ," ", px         ,",", py-fivepix ,"' "
print "-draw 'line "  ,px-fivepix ,",", py         ," ", px+fivepix ,",", py         ,"' "
print "-stroke orange "
print "-draw 'line "  ,lx         ,",", ly+fivepix ," ", lx         ,",", ly-fivepix ,"' "
print "-draw 'line "  ,lx-fivepix ,",", ly         ," ", lx+fivepix ,",", ly         ,"' "
# write the star names
print "-font Symbol -fill white  -stroke white  -draw \qtext " ,px+7," ", py+2," 'a'\q "
print "-font Symbol -fill orange -stroke orange -draw \qtext " ,lx+7," ", ly+2," 'l'\q "
# crop it
print "-crop ",maxx-minx+2*border,"x", maxy-miny+2*border,"+",minx-border,"+",miny-border," "
# write the legend
print "-pointsize 16 -font Courier "
print "-fill green -stroke cyan "
print "-draw \qtext ",maxx+border-80," ",miny-border+20," 'NCP NOW'\q "
print "-fill green -stroke green "
print "-draw \qtext ",maxx+border-80," ",miny-border+40," 'NCP 2000'\q "
print "-fill red -stroke red "
print "-draw \qtext ",maxx+border-80," ",miny-border+60," 'Scope'\q "
#write the diffs
print "-fill white -stroke white "
print "-draw \qtext ",minx-border+5," ",miny-border+20," 'dx:",ncpx-rax, " pixels'\q "
print "-draw \qtext ",minx-border+5," ",miny-border+40," 'dy:",ncpy-ray, " pixels'\q "
print "-draw \qtext ",minx-border+5," ",miny-border+60," '"
# the filename will be written later as bc can't read strings
quit
EOF
chmod 700 ${WORKDIR}/.plot.bc 
cat > ${WORKDIR}/ra_gsl_solver.c<<EOF
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <gsl/gsl_vector.h>
#include <gsl/gsl_multiroots.h>
#include "anwcs.h"

static anwcs_t* wcs1 = NULL;
static anwcs_t* wcs2 = NULL;
int fvec(const gsl_vector *x, void *params, gsl_vector *f)
{
  double ra,dec,xp,yp;
  double xi = gsl_vector_get(x,0);
  double yi = gsl_vector_get(x,1);
  anwcs_pixelxy2radec(wcs1, xi, yi, &ra, &dec);
  anwcs_radec2pixelxy(wcs2, ra, dec, &xp, &yp);
  xp = xp - xi;
  yp = yp - yi;
  gsl_vector_set(f,0,xp);
  gsl_vector_set(f,1,yp);
  return GSL_SUCCESS;
}
int print_state (size_t iter, gsl_multiroot_fsolver * s)
{
  fprintf(stderr,"%d: %16.6f %16.6f\n",iter,
	  gsl_vector_get(s->x,0),
	  gsl_vector_get(s->x,1));
  return 1;
}

int main(int argc, char** args) {
  int ext = 0;
  double x_init[2];
  double ra,dec;
  double sol[2];
  const gsl_multiroot_fsolver_type *T;
  gsl_multiroot_fsolver *s;
  int status;
  size_t iter=0;
  const size_t n=2;
  gsl_multiroot_function f={&fvec,n,NULL};
  gsl_vector *x = gsl_vector_alloc(n);
  FILE *fp;
  
  /*get starting values, the Polaris pixel coords */
  
  fp=fopen("${WORKDIR}/.PRA1x","r");    if (!fp) exit(1);
  fscanf(fp,"%lf\n",&x_init[0]);  fclose(fp);
  fp=fopen("${WORKDIR}/.PRA1y","r");    if (!fp) exit(1);
  fscanf(fp,"%lf\n",&x_init[1]);  fclose(fp);
  
  /* open the two wcs systems */
  wcs1 = anwcs_open("${WORKDIR}/${PREFIX}1.wcs", ext);
  wcs2 = anwcs_open("${WORKDIR}/${PREFIX}2.wcs", ext);
  if(!wcs1 || !wcs2) exit(1);
  
  /* setup the solver */
  gsl_vector_set(x,0,x_init[0]);
  gsl_vector_set(x,1,x_init[1]);
  T = gsl_multiroot_fsolver_hybrids;
  s = gsl_multiroot_fsolver_alloc (T,2);
  gsl_multiroot_fsolver_set(s,&f,x);
  print_state(iter,s);
  do {
    iter++;
    status = gsl_multiroot_fsolver_iterate(s);
    print_state(iter,s);
    if (status) break;
    status = gsl_multiroot_test_residual(s->f,1e-7);
  } while (status == GSL_CONTINUE && iter < 1000);
  sol[0]=gsl_vector_get(s->x,0);
  sol[1]=gsl_vector_get(s->x,1);

  /* write the solution */
  fp=fopen("${WORKDIR}/.RAx","w"); if (!fp) exit(1);
  fprintf(fp,"%f\n",sol[0]); fclose(fp);
  fp=fopen("${WORKDIR}/.RAy","w"); if (!fp) exit(1);
  fprintf(fp,"%f\n",sol[1]); fclose(fp);
  
  /* write some diagnostics on stderr */
  /* transform to ra/dec */
  anwcs_pixelxy2radec(wcs1, sol[0], sol[1], &ra, &dec);
  fprintf(stderr,"Pixel (%.10f, %.10f) -> RA,Dec (%.10f, %.10f)\n", 
	  sol[0], sol[1], ra, dec);
  /* transform to x/y with second wcs 
     center of rotation should stay the same x/y */
  anwcs_radec2pixelxy(wcs2, ra, dec, &sol[0], &sol[1]);
  fprintf(stderr,"RA,Dec (%.10f, %.10f) -> Pixel (%.10f, %.10f) \n", 
	  ra, dec, sol[0], sol[1]);
  return(0);
}
EOF
}
function files () {
	FILE=$(zenity --title "Choose an image" --file-selection --file-filter="*.[jJ][pP]*[gG]")
	if [ -z "${FILE}" ] ; then 
	    zenity --error --text "file selection cancelled!" --timeout 10
	    exec ./polar.sh
	fi
	echo $FILE > ${WORKDIR}/.$1.txt
}

function solve() {
	FILE=$1
	COPY=$2
	OPTS=$3
	# solve, generating .wcs file
	echo solve-field -B none -P none -M none -S none -R none -U none -N none \
	    --no-plots --overwrite --temp-dir ${WORKDIR} --dir ${WORKDIR} --out ${COPY} ${OPTS} ${FILE}
	solve-field -B none -P none -M none -S none -R none -U none -N none \
	    --no-plots --overwrite --temp-dir ${WORKDIR} --dir ${WORKDIR} --out ${COPY} ${OPTS} ${FILE}\
            2>/dev/null  1>> ${WORKDIR}/.solve.log 
}
function modify () {
    if [ -f ${HOME}/.polar/.exptime ] ; then
	EXPTIME=$(zenity --scale --title "Set exposure time" --text "Set exposure time in seconds" \
	    --min-value=1 --max-value=600 --value=$(cat  ${HOME}/.polar/.exptime ) 2>/dev/null )
	echo $EXPTIME >  ${HOME}/.polar/.exptime
    else
	EXPTIME=$(zenity --scale --title "Set exposure time" --text "Set exposure time in seconds" \
	    --min-value=1 --max-value=600 --value=60 2>/dev/null )
	echo $EXPTIME >  ${HOME}/.polar/.exptime
    fi
    if [ -f  ${HOME}/.polar/.declination ] ; then
	TARDEC=$(zenity --scale --title "Declination of target" --text "Declination of target in degrees" \
	    --min-value=0 --max-value=90 --value=$(cat  ${HOME}/.polar/.declination) 2>/dev/null )
	echo $TARDEC >  ${HOME}/.polar/.declination
    else
	TARDEC=$(zenity --scale --title "Declination of target" --text "Declination of target in degrees" \
	    --min-value=0 --max-value=90 --value=0 2>/dev/null )
	echo $TARDEC >  ${HOME}/.polar/.declination
    fi
    if [ -f ${HOME}/.polar/.cameras ] ; then 
	SOLVEOPTS=$(grep -v \^\# ${HOME}/.polar/.cameras | zenity --list --width=1000 --height=300 \
	    --title="Camera and Optics Selection" --text "Choose a camera optics combination for solve options" --radiolist \
	    --column=Choice --column=Description --column=Options \
	    --print-column=3)
	echo $SOLVEOPTS >  ${HOME}/.polar/.solveopts
    else
	if [ -f  ${HOME}/.polar/.solveopts ] ; then
	    SOLVEOPTS=$(zenity --width=800 --entry --title "Solve options" --text "Enter new options:"\
            --entry-text="$(cat  ${HOME}/.polar/.solveopts)" 2>/dev/null)
	    echo $SOLVEOPTS >  ${HOME}/.polar/.solveopts
	else
	    SOLVEOPTS=$(zenity --width=800 --entry --title "Solve options" --text "Enter new options:" \
		2> /dev/null )
	    echo $SOLVEOPTS >  ${HOME}/.polar/.solveopts
	fi
    fi
    if [ -f ${HOME}/.polar/.astrometry ] ; then
	if zenity --question --text="Is this the correct directory for astrometry.net?\n\n $(cat ~/.polar/.astrometry)" \
	    --ok-label=Yes --cancel-label=Browse ; then
	    true
	else
	    rm ${HOME}/.polar/.astrometry
	fi
    fi
    if [ ! -f ${HOME}/.polar/.astrometry ] ; then 
	ASTROMETRY=$(zenity --file-selection --directory --title "Path to astrometry.net software" 2>/dev/null )
	echo $ASTROMETRY >  ${HOME}/.polar/.astrometry
	if [ ! -f $(cat  ${HOME}/.polar/.astrometry)/blind/solve-field.c ] ; then
	    zenity --error --text "Couldn't find astrometry.net software at that location" --timeout 10
	    rm ${HOME}/.polar/.astrometry 
	fi
    fi
}

function output () {
    sfname1=$(basename $(cat ${WORKDIR}/.Ra1.txt))
    sfname2=$(basename $(cat ${WORKDIR}/.Ra2.txt))
    PRA1x=$(cat ${WORKDIR}/.PRA1x)
    PRA1y=$(cat ${WORKDIR}/.PRA1y)
    LRA1x=$(cat ${WORKDIR}/.LRA1x)
    LRA1y=$(cat ${WORKDIR}/.LRA1y)
    PRA2x=$(cat ${WORKDIR}/.PRA2x)
    PRA2y=$(cat ${WORKDIR}/.PRA2y)
    LRA2x=$(cat ${WORKDIR}/.LRA2x)
    LRA2y=$(cat ${WORKDIR}/.LRA2y)
    PRA1x_of=$(cat ${WORKDIR}/.PRA1x_of)
    PRA1y_of=$(cat ${WORKDIR}/.PRA1y_of)
    LRA1x_of=$(cat ${WORKDIR}/.LRA1x_of)
    LRA1y_of=$(cat ${WORKDIR}/.LRA1y_of)
    PRA2x_of=$(cat ${WORKDIR}/.PRA2x_of)
    PRA2y_of=$(cat ${WORKDIR}/.PRA2y_of)
    LRA2x_of=$(cat ${WORKDIR}/.LRA2x_of)
    LRA2y_of=$(cat ${WORKDIR}/.LRA2y_of)
    RAx=$(cat ${WORKDIR}/.RAx)
    RAy=$(cat ${WORKDIR}/.RAy)
    ImgScaa=$(cat ${WORKDIR}/.ImgScaa)
    NCPpos1x=$(cat ${WORKDIR}/.NCPpos1x)
    NCPpos1y=$(cat ${WORKDIR}/.NCPpos1y)
    NCPpos2x=$(cat ${WORKDIR}/.NCPpos2x)
    NCPpos2y=$(cat ${WORKDIR}/.NCPpos2y)
    Moffp1x=$(cat ${WORKDIR}/.Moffp1x)
    Moffp1y=$(cat ${WORKDIR}/.Moffp1y)
    Moffp2x=$(cat ${WORKDIR}/.Moffp2x)
    Moffp2y=$(cat ${WORKDIR}/.Moffp2y)
    EXPTIME=$(cat  ${HOME}/.polar/.exptime)
    MoffdRA1x=$(cat ${WORKDIR}/.MoffdRA1x)
    MoffdRA2x=$(cat ${WORKDIR}/.MoffdRA2x)
    MoffdRA1y=$(cat ${WORKDIR}/.MoffdRA1y)
    MoffdRA2y=$(cat ${WORKDIR}/.MoffdRA2y)
    PAerrdmsRA1=$(cat ${WORKDIR}/.PAerrdmsRA1)
    PAerrdmsRA2=$(cat ${WORKDIR}/.PAerrdmsRA2)
    PAerrRA1=$(cat ${WORKDIR}/.PAerrRA1)
    PAerrRA2=$(cat ${WORKDIR}/.PAerrRA2)
    DECdarc=$(cat ${WORKDIR}/.Decdarc)
    DECdpix=$(cat ${WORKDIR}/.Decdpix)
    
    GREEN="\033[1;32m"
    BLUE="\033[1;34m"
    RED="\033[1;31m"
    NC="\033[0m"
    
    printf %b%s%s%b\\n $GREEN "##################################################################"\
                   "#############################################" $NC
    printf %57s%-32s%-32s\\n " " "RA Position 1" "RA Position 2"
    printf %57s%-32s%-32s\\n " " $sfname1 $sfname2
    printf %-57s%b%-32d%d%b\\n "Polaris (Alpha Ursa Minoris) x pixel: " $GREEN $PRA1x $PRA2x $NC
    printf %-57s%b%-32d%d%b\\n "Polaris (Alpha Ursa Minoris) y pixel: " $GREEN $PRA1y $PRA2y $NC
    printf %-57s%b%-32d%d%b\\n "Lambda Ursa Minoris (opposite the Engagement Ring): " \
$GREEN $LRA1x $LRA2x $NC
    printf %-57s%b%-32d%d%b\\n "Lambda Ursa Minoris (opposite the Engagement Ring): " \
$GREEN $LRA1y $LRA2y $NC
    printf %-57s%b%-32d%d%b\\n "After offset Polaris x pixel: " $RED $PRA1x_of $PRA2x_of $NC
    printf %-57s%b%-32d%d%b\\n "After offset Polaris y pixel: " $RED $PRA1y_of $PRA2y_of $NC
    printf %-57s%b%-32d%d%b\\n "After offset Lambda: x pixel: " $RED $LRA1x_of $LRA2x_of $NC
    printf %-57s%b%-32d%d%b\\n "After offset Lambda: y pixel: " $RED $LRA1y_of $LRA2y_of $NC
    printf %-57s%b%-32s%s%b\\n "PA error (arc deg:minutes:seconds)" \
$GREEN $PAerrdmsRA1  $PAerrdmsRA2 $NC
    echo "------------"
    printf %-57s%b%-32d%b\\n "RA axis (intersection of perpendicular bisectors) x" $BLUE $RAx $NC
    printf %-57s%b%-32d%b\\n "RA axis (intersection of perpendicular bisectors) y" $BLUE $RAy $NC
    printf %-57s%b%-32d%d%b\\n "NCP x: " $BLUE $NCPpos1x  $NCPpos2x $NC
    printf %-57s%b%-32d%d%b\\n "NCP y: " $BLUE $NCPpos1y  $NCPpos2y $NC
    printf %-57s%b%-32d%d%b\\n "offset mount in x (pixels): " $BLUE $Moffp1x $Moffp2x $NC
    printf %-57s%b%-32d%d%b\\n "offset mount in y (pixels): " $BLUE $Moffp1y $Moffp2y $NC
    printf %-57s%b%-32s%s%b\\n "offset mount in x (degrees:minutes:seconds)" \
$GREEN $MoffdRA1x $MoffdRA2x $NC
    printf %-57s%b%-32s%s%b\\n "offset mount in y (degrees:minutes:seconds)" \
$GREEN $MoffdRA1y $MoffdRA2y $NC
    echo "------------"
    printf %-57s%b%-32.3f%8s%b\\n "J2000 Declination of NCP (deg):" $GREEN $ncpdec $ncpdecsexa $NC
    printf %-57s%b%-32.3f%8s%b\\n "J2000 Right Ascension of NCP (hr):" $GREEN $ncprahour $ncprahoursexa $NC
    printf %-57s%b%-32.2f%b\\n "image scale (arc-seconds / pixel)" $GREEN $ImgScaa $NC
    printf %-57s%b%-32.2f%b\\n "Exposure time (seconds):" $GREEN $EXPTIME $NC
    printf %-57s%b%-32.2f%b\\n "At declination (degrees):" $GREEN $TARDEC $NC
    printf %-57s%b%-7.2farcseconds%b\\n "error induced drift :" $GREEN $DECdarc  $NC
    printf %-57s%b%-7.2fpixels%b\\n "error induced drift :" $GREEN $DECdpix $NC
    printf %b\\n $NC
    
}
function getx() {
    wcs-rd2xy -r $1 -d $2 -w $3 | awk '{printf "%s\n",substr($6,2,length($6)-2)}'
}
function gety() {
    wcs-rd2xy -r $1 -d $2 -w $3 | awk '{printf "%s\n",substr($7,1,length($7)-1)}'
}

#START
dot_files
if [ ! -f ${HOME}/.polar/.astrometry ] ; then
	modify
fi

EXPTIME=$(cat ${HOME}/.polar/.exptime )
TARDEC=$(cat ${HOME}/.polar/.declination)
SOLVEOPTS=$(cat ${HOME}/.polar/.solveopts)
ASTROMETRY=$(cat ${HOME}/.polar/.astrometry )

ready_progs
JNOW

while [ true ]; do
    
    MODE=$(zenity --width=600 --height=300 --list  --title="Photographic Polar Alignment"\
--text="Choose an operation"  --radiolist \
--column="Choice" --column="Action" --column="Description"  \
TRUE  Solve   "Estimate the position of the RA axis from two images" \
FALSE Display "Print details of the current RA axis solution" \
FALSE Plots   "Display annotated images for the current RA axis solution" \
FALSE Verify  "Check an image for closeness to NCP"  \
FALSE Modify  "Change parameters" \
FALSE Clean   "Clean up generated files" \
FALSE Exit    "Quit the program" 2>/dev/null)

    if [ "${MODE}" = "Display" ] ; then
	output
    elif [ "${MODE}" = "Clean" ] ; then
	rm -rf ${WORKDIR}
	mkdir ${WORKDIR}
    elif [ "${MODE}" = "Plots" ] ; then
	fname1=$(cat ${WORKDIR}/.Ra1.txt)
	fname2=$(cat ${WORKDIR}/.Ra2.txt)
	cat ${WORKDIR}/.PRA1x ${WORKDIR}/.LRA1x ${WORKDIR}/.NCPpos1x ${WORKDIR}/.RAx ${WORKDIR}/.PRA1y \
	    ${WORKDIR}/.LRA1y ${WORKDIR}/.NCPpos1y ${WORKDIR}/.RAy ${WORKDIR}/.ImgScaa \
	    ${WORKDIR}/.NCPpos1x2000 ${WORKDIR}/.NCPpos1y2000 \
	    |BC_LINE_LENGTH=2000  ${WORKDIR}/.plot.bc  > ${WORKDIR}/plot1.sh
	chmod 700 ${WORKDIR}/plot1.sh
	echo -n $(basename $fname1) "'\" - - ">> ${WORKDIR}/plot1.sh
	
	cat ${WORKDIR}/.PRA2x ${WORKDIR}/.LRA2x ${WORKDIR}/.NCPpos2x ${WORKDIR}/.RAx ${WORKDIR}/.PRA2y \
	    ${WORKDIR}/.LRA2y ${WORKDIR}/.NCPpos2y ${WORKDIR}/.RAy ${WORKDIR}/.ImgScaa \
	    ${WORKDIR}/.NCPpos2x2000 ${WORKDIR}/.NCPpos2y2000 \
	    |BC_LINE_LENGTH=2000  ${WORKDIR}/.plot.bc > ${WORKDIR}/plot2.sh
	chmod 700 ${WORKDIR}/plot2.sh
	echo -n $(basename $fname2) "'\" - - ">> ${WORKDIR}/plot2.sh
	
    cat $fname1 | ${WORKDIR}/plot1.sh 2>/dev/null |display - & 
    cat $fname2 | ${WORKDIR}/plot2.sh 2>/dev/null |display - & 
    
    elif [ "${MODE}" = "Modify" ] ; then
	modify
    elif [ "${MODE}" = "Verify" ] ; then
	files Ra3
	fname3=$(cat ${WORKDIR}/.Ra3.txt)
	solve $fname3 ${PREFIX}3 "$SOLVEOPTS"
	ImgScaa=$(cat ${WORKDIR}/.ImgScaa)
	rax=$(cat ${WORKDIR}/.RAx)
	ray=$(cat ${WORKDIR}/.RAy)
	px=$(getx $POLRA $POLDEC ${WORKDIR}/${PREFIX}3.wcs)
	py=$(gety $POLRA $POLDEC ${WORKDIR}/${PREFIX}3.wcs)
	lx=$(getx $LAMRA $LAMDEC ${WORKDIR}/${PREFIX}3.wcs)
	ly=$(gety $LAMRA $LAMDEC ${WORKDIR}/${PREFIX}3.wcs)
	nx=$(getx $ncpradeg $ncpdec ${WORKDIR}/${PREFIX}3.wcs)
	ny=$(gety $ncpradeg $ncpdec ${WORKDIR}/${PREFIX}3.wcs)
	nx2000=$(getx 0 90 ${WORKDIR}/${PREFIX}3.wcs)
	ny2000=$(gety 0 90 ${WORKDIR}/${PREFIX}3.wcs)
	printf %.0f\\n%.0f\\n%.0f\\n%.0f\\n%.0f\\n%.0f\\n%.0f\\n%.0f\\n%.0f\\n%.0f\\n%.0f\\n \
	    $px $lx $nx $rax $py $ly $ny $ray $ImgScaa $nx2000 $ny2000 |\
        BC_LINE_LENGTH=2000  ${WORKDIR}/.plot.bc  > ${WORKDIR}/plot3.sh
	chmod 700 ${WORKDIR}/plot3.sh
	echo -n $(basename $fname3) "'\" - - ">> ${WORKDIR}/plot3.sh
	cat $fname3| ${WORKDIR}/plot3.sh |display - & 
	
	GREEN="\033[1;32m"
	NC="\033[0m"
	printf %b%s%s%b\\n $GREEN "##################################################################"\
                   "#############################################" $NC
	printf %57s%-32s\\n " " $(basename $fname3)
	printf %-57s%b%-6.0f%6.0f%b\\n "Mount RA axis x pixel and target : " $GREEN $rax  $nx $NC 
	printf %-57s%b%-6.0f%6.0f%b\\n "Mount RA axis y pixel and target : " $GREEN $ray  $ny $NC 
	printf %-57s%b%-32.0f%b\\n "Polaris (Alpha Ursa Minoris) x pixel: " $GREEN $px $NC
	printf %-57s%b%-32.0f%b\\n "Polaris (Alpha Ursa Minoris) y pixel: " $GREEN $py $NC
	printf %-57s%b%-32.0f%b\\n "Lambda Ursa Minoris (opposite the Engagement Ring): " \
	    $GREEN $lx $NC
	printf %-57s%b%-32.0f%b\\n "Lambda Ursa Minoris (opposite the Engagement Ring): " \
	    $GREEN $ly  $NC
	
	
    elif [ "${MODE}" = "Solve" ] ; then
	
	files Ra1
	files Ra2
	rm -f ${WORKDIR}/${PREFIX}1.wcs ${WORKDIR}/${PREFIX}2.wcs
	fname1=$(cat ${WORKDIR}/.Ra1.txt)
	fname2=$(cat ${WORKDIR}/.Ra2.txt)
	rm -f  ${WORKDIR}/.solve.log
	solve $fname1 ${PREFIX}1 "$SOLVEOPTS"
	solve $fname2 ${PREFIX}2 "$SOLVEOPTS"
	if [ ! -f ${WORKDIR}/${PREFIX}1.wcs -o ! -f ${WORKDIR}/${PREFIX}2.wcs ] ; then
	    zenity --text-info --title  "Couldn't solve the images" --filename=${WORKDIR}/.solve.log --width=800 --height=800
	    zenity --text-info --filename=$HOME/.polar/.cameras --editable --height=600 --width=800 1> $HOME/.polar/.cameras.new
	    mv $HOME/.polar/.cameras.new $HOME/.polar/.cameras
	    exec ./polar.sh
	fi
	ImgScaa=$(wcsinfo  ${WORKDIR}/${PREFIX}1.wcs |grep pixscale|awk '{printf "%.4f\n", $2}')
	printf %.2f\\n $ImgScaa > ${WORKDIR}/.ImgScaa
	
###############
# Polaris x/y #
###############
	c3=$(getx $POLRA $POLDEC ${WORKDIR}/${PREFIX}1.wcs)
	c4=$(gety $POLRA $POLDEC ${WORKDIR}/${PREFIX}1.wcs)
	d3=$(getx $POLRA $POLDEC ${WORKDIR}/${PREFIX}2.wcs)
	d4=$(gety $POLRA $POLDEC ${WORKDIR}/${PREFIX}2.wcs)
###############
# Lambda x/y #
###############
	c5=$(getx $LAMRA $LAMDEC ${WORKDIR}/${PREFIX}1.wcs)
	c6=$(gety $LAMRA $LAMDEC ${WORKDIR}/${PREFIX}1.wcs)
	d5=$(getx $LAMRA $LAMDEC ${WORKDIR}/${PREFIX}2.wcs)
	d6=$(gety $LAMRA $LAMDEC ${WORKDIR}/${PREFIX}2.wcs)
    
	printf %.0f\\n $c3 > ${WORKDIR}/.PRA1x
	printf %.0f\\n $c4 > ${WORKDIR}/.PRA1y
	printf %.0f\\n $c5 > ${WORKDIR}/.LRA1x
	printf %.0f\\n $c6 > ${WORKDIR}/.LRA1y
	printf %.0f\\n $d3 > ${WORKDIR}/.PRA2x
	printf %.0f\\n $d4 > ${WORKDIR}/.PRA2y
	printf %.0f\\n $d5 > ${WORKDIR}/.LRA2x
	printf %.0f\\n $d6 > ${WORKDIR}/.LRA2y
	


#######################
## new RA axis solve ##
#######################
#
# solve f(x)=x where f is the function that takes (x,y) from first image
# to the same object's (x,y) in the second image
# ra_gsl_solver needs:
#       the 2 .wcs files to be in place and have valid data
#       the .PRA1x .PRA1y files to be in place and have valid data
#               writes:
#       the .RAx .RAy files
	rm -f ${WORKDIR}/.RAx ${WORKDIR}/.RAy
	if [ ! -f ${WORKDIR}/ra_gsl_solver.exe ] ; then
	    echo "Compiling ra_gsl_solver.exe"
	    echo gcc -Wall -c -I ${ASTROMETRY}/util -I ${ASTROMETRY}/qfits-an/include ${WORKDIR}/ra_gsl_solver.c \
		-o ${WORKDIR}/ra_gsl_solver.o
	    gcc -Wall -c -I ${ASTROMETRY}/util -I ${ASTROMETRY}/qfits-an/include ${WORKDIR}/ra_gsl_solver.c \
		-o ${WORKDIR}/ra_gsl_solver.o
	    echo gcc ${WORKDIR}/ra_gsl_solver.o  -lgsl ${ASTROMETRY}/gsl-an/libgsl-an.a \
		${ASTROMETRY}/util/libanutils.a ${ASTROMETRY}/qfits-an/lib/libqfits.a\
       -lwcs -lpthread -o ${WORKDIR}/ra_gsl_solver.exe
	    gcc ${WORKDIR}/ra_gsl_solver.o  -lgsl ${ASTROMETRY}/gsl-an/libgsl-an.a \
		${ASTROMETRY}/util/libanutils.a ${ASTROMETRY}/qfits-an/lib/libqfits.a\
       -lwcs -lpthread -o ${WORKDIR}/ra_gsl_solver.exe
	fi
	if [ ! -f ${WORKDIR}/ra_gsl_solver.exe ] ; then
	    zenity --error --text  "Couldn't compile ra_gsl_solver.exe" --timeout 5 
	    exit
	fi
	${WORKDIR}/ra_gsl_solver.exe 2>${WORKDIR}/.ra_gsl_solver.txt
	if [ ! -f ${WORKDIR}/.RAx -o ! -f ${WORKDIR}/.RAy ] ; then
	    zenity --error --text  "Couldn't solve for RA axis" --timeout 5 
	    exec ./polar.sh
	fi
	RAx=$(cat ${WORKDIR}/.RAx)
	RAy=$(cat ${WORKDIR}/.RAy)
	printf %.0f\\n  $RAx  > ${WORKDIR}/.RAx
	printf %.0f\\n  $RAy  > ${WORKDIR}/.RAy

############
##NCP x y ##
############
	NCPpos1x2000=$(getx 0 90 ${WORKDIR}/${PREFIX}1.wcs)
	NCPpos2x2000=$(getx 0 90 ${WORKDIR}/${PREFIX}2.wcs)
	NCPpos1y2000=$(gety 0 90 ${WORKDIR}/${PREFIX}1.wcs)
	NCPpos2y2000=$(gety 0 90 ${WORKDIR}/${PREFIX}2.wcs)
	NCPpos1x=$(getx $ncpradeg $ncpdec ${WORKDIR}/${PREFIX}1.wcs)
	NCPpos2x=$(getx $ncpradeg $ncpdec ${WORKDIR}/${PREFIX}2.wcs)
	NCPpos1y=$(gety $ncpradeg $ncpdec ${WORKDIR}/${PREFIX}1.wcs)
	NCPpos2y=$(gety $ncpradeg $ncpdec ${WORKDIR}/${PREFIX}2.wcs)
	printf %.0f\\n $NCPpos1x > ${WORKDIR}/.NCPpos1x
	printf %.0f\\n $NCPpos2x > ${WORKDIR}/.NCPpos2x
	printf %.0f\\n $NCPpos1y > ${WORKDIR}/.NCPpos1y
	printf %.0f\\n $NCPpos2y > ${WORKDIR}/.NCPpos2y
	printf %.0f\\n $NCPpos1x2000 > ${WORKDIR}/.NCPpos1x2000
	printf %.0f\\n $NCPpos2x2000 > ${WORKDIR}/.NCPpos2x2000
	printf %.0f\\n $NCPpos1y2000 > ${WORKDIR}/.NCPpos1y2000
	printf %.0f\\n $NCPpos2y2000 > ${WORKDIR}/.NCPpos2y2000
	
	
##############################
##offset mount in x (pixels)##
##offset mount in y (pixels)##
##############################
	Moffp1x=$(echo "scale=20;($NCPpos1x) - ($RAx)" | bc -l)
	Moffp2x=$(echo "scale=20;($NCPpos2x) - ($RAx)" | bc -l)
	Moffp1y=$(echo "scale=20;($NCPpos1y) - ($RAy)" | bc -l)
	Moffp2y=$(echo "scale=20;($NCPpos2y) - ($RAy)" | bc -l)
	printf %.0f\\n $Moffp1x > ${WORKDIR}/.Moffp1x
	printf %.0f\\n $Moffp2x > ${WORKDIR}/.Moffp2x
	printf %.0f\\n $Moffp1y > ${WORKDIR}/.Moffp1y
	printf %.0f\\n $Moffp2y > ${WORKDIR}/.Moffp2y

########################
##After offset Polaris##
########################
	PRA1x_of=$(echo "scale=20;($c3) - ($Moffp1x)" | bc -l)
	PRA1y_of=$(echo "scal2=20;($c4) - ($Moffp1y)" | bc -l)
	LRA1x_of=$(echo "scale=20;($c5) - ($Moffp1x)" | bc -l)
	LRA1y_of=$(echo "scale=20;($c6) - ($Moffp1y)" | bc -l)
	PRA2x_of=$(echo "scale=20;($d3) - ($Moffp2x)" | bc -l)
	PRA2y_of=$(echo "scale=20;($d4) - ($Moffp2y)" | bc -l)
	LRA2x_of=$(echo "scale=20;($d5) - ($Moffp2x)" | bc -l)
	LRA2y_of=$(echo "scale=20;($d6) - ($Moffp2y)" | bc -l)
	printf %.0f\\n $PRA1x_of > ${WORKDIR}/.PRA1x_of
	printf %.0f\\n $PRA1y_of > ${WORKDIR}/.PRA1y_of
	printf %.0f\\n $LRA1x_of > ${WORKDIR}/.LRA1x_of
	printf %.0f\\n $LRA1y_of > ${WORKDIR}/.LRA1y_of
	printf %.0f\\n $PRA2x_of > ${WORKDIR}/.PRA2x_of
	printf %.0f\\n $PRA2y_of > ${WORKDIR}/.PRA2y_of
	printf %.0f\\n $LRA2x_of > ${WORKDIR}/.LRA2x_of
	printf %.0f\\n $LRA2y_of > ${WORKDIR}/.LRA2y_of
	
######################################
##PA error (arc deg:minutes:seconds)##
######################################
	PAerrRA1=$(echo "scale=20;dx=($NCPpos1x)-($RAx);dy=($NCPpos1y)-($RAy);\
    $ImgScaa * sqrt(dx*dx+dy*dy)"| tee ${WORKDIR}/.logPAerrRA1.bc| bc -l)
	PAerrRA2=$(echo "scale=20;dx=($NCPpos2x)-($RAx);dy=($NCPpos2y)-($RAy);\
    $ImgScaa * sqrt(dx*dx+dy*dy)"| tee ${WORKDIR}/.logPAerrRA2.bc| bc -l)
	printf %.0f\\n $PAerrRA2  > ${WORKDIR}/.PAerrRA2
	printf %.0f\\n $PAerrRA1  > ${WORKDIR}/.PAerrRA1
	printf %.0f\\n $PAerrRA2 | ${WORKDIR}/.hexa.bc > ${WORKDIR}/.PAerrdmsRA2
	printf %.0f\\n $PAerrRA1 | ${WORKDIR}/.hexa.bc > ${WORKDIR}/.PAerrdmsRA1


###############################################
##offset mount in x (degrees:minutes:seconds)##
##offset mount in y (degrees:minutes:seconds)##
###############################################
	MoffdRA1x=$(echo "scale=20;($Moffp1x) * ($ImgScaa)" | bc -l)
	MoffdRA2x=$(echo "scale=20;($Moffp2x) * ($ImgScaa)" | bc -l)
	MoffdRA1y=$(echo "scale=20;($Moffp1y) * ($ImgScaa)" | bc -l)
	MoffdRA2y=$(echo "scale=20;($Moffp2y) * ($ImgScaa)" | bc -l)
	printf %.0f\\n $MoffdRA2x | ${WORKDIR}/.hexa.bc > ${WORKDIR}/.MoffdRA2x
	printf %.0f\\n $MoffdRA1x | ${WORKDIR}/.hexa.bc > ${WORKDIR}/.MoffdRA1x
	printf %.0f\\n $MoffdRA1y | ${WORKDIR}/.hexa.bc > ${WORKDIR}/.MoffdRA1y
	printf %.0f\\n $MoffdRA2y | ${WORKDIR}/.hexa.bc > ${WORKDIR}/.MoffdRA2y
	
##########################################################
##Induced declination drift due to PA error (arcseconds)##
##########################################################
	DECdarc=$(echo "scale=20; ((($PAerrRA1)+($PAerrRA2))/120)*c((4*a(1)*($TARDEC))/180) \
    *($EXPTIME)/(20*a(1))" | tee ${WORKDIR}/.logDECdarc.bc| bc -l)
	printf %.0f\\n $DECdarc > ${WORKDIR}/.Decdarc
	
######################################################
##Induced declination drift due to PA error (pixels)##
######################################################
	DECdpix=$(echo "scale=20;($DECdarc)/($ImgScaa)" | bc -l)
	printf %.0f\\n $DECdpix > ${WORKDIR}/.Decdpix
	
	output
	
    elif [ "${MODE}" = "Exit" ] ; then
        exit
    fi

done
